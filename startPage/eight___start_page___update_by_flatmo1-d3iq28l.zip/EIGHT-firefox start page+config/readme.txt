EIGHT - Firefox start page
by Lubomir Krupa
[http://krupa.kx.cz]   [http://krupa.euweb.cz]
[http://eight.kx.cz]

---

Work is released under Creative Commons Attribution-NoDerivs 3.0 license.

Instructions:

1.	Place folder somewhere in your harddisk.
2.	Place images of thumbnails to 'thumbs' folder. Maximal dimensions of thumbnails should be set according to 'sketch.jpg'. For best look use clear white images with alpha transparency.
3.	Run 'config.htm' to generate file with your settings. Copy generated text into 'source.js'.
3a.	You can edit 'source.js' manually:
		3a.1.	Set whether you want hover effect or not		[line 1]
		3a.2.	Set your favourite search engine		[line 3]
		3a.3.	Set number of screens		[line 5]
		3a.4.	Set block names		[lines 8-10]
		3a.5.	Set bookmarks parameters. Numbering of bookmarks you can find in 'sketch.jpg'. If you do not fill 'thumb' for thumbnail will be used title.		[from line 19]
					- bookmark[0][0] mean, that it is first bookmark on first screen, so bookmark[1][5] mean, that it is sixth bookmark on second screen
4.	Set 'index.htm' as your start page in browser of your choice.
5.	Use clicking on arrow icons, keybord arrows or mouse wheel for moving between blocks.